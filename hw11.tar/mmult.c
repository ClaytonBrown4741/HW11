/* 
* mmult.c
* Author: Clayton Brown
* Date: May 5, 2023
*
* COSC 3750, Homework 11
*
* This code is used to multiply complicated matrices
* while using threads if that's what the user wants
*
*/


// Import the necessary packages
#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h> 
#include "matrixInfo.h"



// void *threadFunction(void *arg)
// Parameters: A structure holding matrix information
// Return value: An int describing whether an error occured
// This is the thread function that computes the matrix info
void *threadFunction(void *arg)
{
   // Declare my variables
   struct matrixInfo* thread = arg;
   int currentRow=0;
   int currentCol=1;
   int rowLimit=0;
   int colLimit=0;
   int rtn=0;
   rowLimit=thread->aRows;
   colLimit=thread->bCol;

   // Loop until the matrix is fully computed
   while (1){ 
        // Lock the mutex and compute the necessary values
        rtn = pthread_mutex_lock(thread->mutex);
        if (rtn!=0){
            fprintf(stderr, "ERROR WITH LOCKING MUTEX");
        }
        if(thread->row > rowLimit-1 && thread->col>=colLimit){
            pthread_mutex_unlock(thread->mutex);
            pthread_exit(0);
            return (0);
        }
        else if (thread->row > rowLimit-1){
            thread->row=1;
            thread->col++;
        }
        else
            thread->row++;

        currentRow=thread->row;
        currentCol=thread->col;

	// Unlock the mutex and calculate the matrix
        rtn=pthread_mutex_unlock(thread->mutex);
        if (rtn!=0){
            fprintf(stderr, "ERROR WITH LOCKING MUTEX");
        }
        if (currentRow <= rowLimit && currentCol <= colLimit){
            for(int i=currentRow-1;i<currentRow;i++){
              for(int j=currentCol-1;j<currentCol;j++){
                  for(int k=0;k<thread->aCol;k++){
                      thread->matrixC[i*thread->bCol + j]
                      += thread->matrixA[i*thread->aCol + k]
                      * thread->matrixB[k*thread->bCol + j];
                  }
              }
           }
       }
   }
   return (0);
}



// matrixMult(int numOfThreads, struct matrixInfo info)
// Parameters: Number of threads that are needed, and a structure
//    that holds information about the matrices
// Return Value: Int that says whether it succeeded or not
// This function is what makes the threads and waits for them
//    to complete
int matrixMult(int numOfThreads, struct matrixInfo info)
{
   // Initialize and declare my variables
   pthread_cond_t testCond = PTHREAD_COND_INITIALIZER;
   pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
   pthread_mutex_t fileProtector = PTHREAD_MUTEX_INITIALIZER;
   int rtn=0;
   pthread_t *tid;
   info.row=0;
   info.col=1;
   info.mutex=&lock;
   info.cv=&testCond;
   info.fileMutex=&fileProtector;

   // Make the threads
   tid=calloc(numOfThreads,sizeof(pthread_t));

   // Run all of the threads
   for (int i=0;i<numOfThreads;i++){
     rtn=pthread_create(&tid[i],NULL,threadFunction,&info);
     if(rtn) {
         fprintf(stderr,"pthread_create: %s\n",strerror(rtn));
         return 1;
     }
   }

   // Wait for the threads to terminate before moving on
   for (int i=0;i<numOfThreads;i++){
       pthread_join(tid[i],NULL);
       if(rtn) {
           fprintf(stderr,"pthread_join: %s\n",strerror(rtn));
           return 1;
      }
   }
   
    // Print the information to a file
    int total3=info.aRows*info.bCol;
    rtn = fwrite(&info.aRows,1,sizeof(int),info.outputFile);
    if (rtn==0){
        fprintf(stderr, "ERROR WRITING ROWS TO FILES");
    }
    rtn = fwrite(&info.bCol,1,sizeof(int),info.outputFile);
    if (rtn==0){
        fprintf(stderr, "ERROR WRITING COLUMNS TO FILES");
    }


    for (int i=0; i<total3; i++){
        //fprintf(stderr, "%f\n",info.matrixC[i]);
        rtn = fwrite(&info.matrixC[i],1,sizeof(double),info.outputFile);
        if (rtn==0){
            fprintf(stderr, "ERROR WRITING TO FILES");
        }
    }
    rtn=fclose(info.outputFile);
    if (rtn!=0){
        fprintf(stderr, "ERROR TRYING TO CLOSE FILE");
    }

   return 0;
}





int main(int argc, char **argv, char **envp){
    // Define my variables
    FILE *firstMat;
    FILE *secondMat;
    int rtn = 0;
    int columns1=0;
    int rows1=0;
    int columns2=0;
    int rows2=0;
    int total1=0;
    int total2=0;
    int total3=0;
    double valueStorage=0.0;
    struct matrixInfo info;

    // If there are too few arguments, tell the user
    if (argc < 4){
        fprintf(stderr, "ERROR NOT ENOUGH ARGS\n");
        return 1;
    }

    // Open the two files and get the dimensions of the matrices
    firstMat=fopen(argv[1], "r");
    if (firstMat==NULL){
        fprintf(stderr, "ERROR: FIRST FILE DOES NOT EXIST");
        return 0;
    }
    rtn = fread(&rows1,1,sizeof(int),firstMat);
 
    if (rtn==0){
        fprintf(stderr, "ERROR READING ROWS FROM FIRST MATRIX A");
        return 0;
    }
 
    rtn = fread(&columns1,1,sizeof(int),firstMat);
    if (rtn==0){
        fprintf(stderr, "ERROR READING COLUMNS FROM FIRST MATRIX A");
        return 0;
    }
 
    secondMat=fopen(argv[2], "r");
    if (secondMat==NULL){
        fprintf(stderr, "ERROR: FIRST FILE DOES NOT EXIST");
        return 0;
    }
 
    rtn = fread(&rows2,1,sizeof(int),secondMat);
     if (rtn==0){
        fprintf(stderr, "ERROR READING COLUMNS FROM SECOND MATRIX B");
        return 0;
     }

    rtn = fread(&columns2,1,sizeof(int),secondMat);
    if (rtn==0){
        fprintf(stderr, "ERROR READING COLUMNS FROM SECOND MATRIX B");
        return 0;
    }

    // If the columns don't match the rows of the other matrix, tell the user
    if (columns1!=rows2){
        fprintf(stderr, "ERROR: THESE MATRICES ARE NOT THE PROPER SIZE\n");
        return 1;
    }

    if (columns1<=0 || columns2<=0 || rows1<=0 || rows2<=2){
        fprintf(stderr, "CANNOT HAVE NEGATIVE ROW OR COLUMN VALUES");
        return 0;
    }

    //Save the values to a structure
    info.aRows=rows1;
    info.aCol=columns1;
    info.bRows=rows2;
    info.bCol=columns2;
    info.cRows=rows1;
    info.cCol=columns2;

    total1=rows1*columns1;
    total2=rows2*columns2;
    total3=rows1*columns2;

    info.matrixA=(double*)calloc(total1, sizeof(double));
    info.matrixB=(double*)calloc(total2, sizeof(double));
    info.matrixC=(double*)calloc(total3, sizeof(double));

    // Read in the first matrix
   // fprintf(stderr, "MATRIX A:\n");
    for (int i=0; i<total1; i++){
        rtn = fread(&valueStorage,1,sizeof(double),firstMat);
        if (rtn==0){
            fprintf(stderr, "ERROR READING FROM FIRST MATRIX FILE");
            return 0;
        }
        info.matrixA[i]=valueStorage;
     //   fprintf(stderr, "%f\n",info.matrixA[i]);
    }
    rtn=fclose(firstMat);
    if (rtn!=0){
        fprintf(stderr,"ERROR CLOSING FIRST FILE");
    }

    // Read in second matrix
    // fprintf(stderr, "MATRIX B:\n");
    for (int i=0; i<total2; i++){
        rtn=fread(&valueStorage,1,sizeof(double),secondMat);
        if (rtn==0){
            fprintf(stderr, "ERROR READING FROM SECOND MATRIX FILE");
            return 0;
        }
        info.matrixB[i]=valueStorage;
      //  fprintf(stderr, "%f\n",info.matrixB[i]);
    }
    rtn=fclose(secondMat);
    if (rtn!=0){
        fprintf(stderr,"ERROR CLOSING SECOND FILE");
    }

    //  Open and the output file
    FILE* outputFile;
    outputFile=fopen(argv[3], "w");
    if (outputFile==NULL){
        fprintf(stderr, "ERROR OPENING OUTPUT FILE");
        return 0;
    }

    //  Start the timer
    clock_t before = clock();

    //  If threads are given, execute the following
    if (argc==5 && argv[4]!=NULL){
        info.outputFile=outputFile;
        char *p='\0';
        long conv;
        conv=strtol(argv[4], &p, 10);
        if (errno != 0) {
            fprintf(stderr, "DIGIT IT NOT CORRECT");
            return 0;
        }
        int num=0;
        num=conv;
        if (num < 0){
            fprintf(stderr, "CANNOT HAVE NEGATIVE NUM OF THREADS");
            return 0;
        }
        matrixMult(num, info);
        clock_t difference = clock() - before;
	
        // Print out the matrix info
        float mSec = difference * 1000 / CLOCKS_PER_SEC;
        fprintf(stderr, "\nMATRIX SIZES: \n");
        fprintf(stderr, "    M: %d\n", rows1);
        fprintf(stderr, "    N: %d\n", columns1);
        fprintf(stderr, "    P: %d\n", columns2);

        fprintf(stderr, "THREADS USED: %d\n", num);
        fprintf(stderr, "TOTAL TIME TAKEN: %f milliseconds\n\n", mSec);
        return 0;
    }

    
    // If the user didn't use threads, just calculate the matrix
    for(int i=0;i<rows1;i++){
      for(int j=0;j<columns2;j++){
          for(int k=0;k<columns1;k++){
              info.matrixC[i*columns2 + j] += info.matrixA[i*columns1 + k] 
                  * info.matrixB[k*columns2 + j];
          }
      }
    }


    // Print out info about the matrix operation
    clock_t difference = clock() - before;
    float mSec = difference * 1000 / CLOCKS_PER_SEC;
    
    fprintf(stderr, "\nMATRIX SIZES: \n");
    fprintf(stderr, "    M: %d\n", rows1);
    fprintf(stderr, "    N: %d\n", columns1);
    fprintf(stderr, "    P: %d\n", columns2);

    fprintf(stderr, "THREADS USED: 0\n");

    fprintf(stderr, "TOTAL TIME TAKEN: %f milliseconds\n\n", mSec);
    

    // Print out the matrix info to the given file
    rtn=fwrite(&rows1,1,sizeof(int),outputFile);
    if (rtn==0)
        fprintf(stderr, "ERROR WRITING TO FILE");
    rtn=fwrite(&columns2,1,sizeof(int),outputFile);
    if (rtn==0)
        fprintf(stderr, "ERROR WRITING TO FILE");


     //fprintf(stderr, "MATRIX C:\n");
     for (int i=0; i<total3; i++){
       // fprintf(stderr, "%f\n",info.matrixC[i]);
        rtn=fwrite(&info.matrixC[i],1,sizeof(double),outputFile);
        if (rtn==0)
            fprintf(stderr, "ERROR WRITING TO FILE");
    }
    rtn=fclose(outputFile);
    if (rtn!=0)
        fprintf(stderr, "ERROR CLOSING FILE");
}
