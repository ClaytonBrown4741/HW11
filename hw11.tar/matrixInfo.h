/*
* matrixInfo.h
* Author: Clayton Brown
* Date: May 5, 2023
*
* COSC 3750, Homework 11
*
* This code is used to save matrix info for use
* in threads
*
*/


#ifndef MATRIX_HEADER_
#define MATRIX_HEADER_

#include<stdio.h>

struct matrixInfo
{
    double *matrixA;
    double *matrixB;
    double *matrixC;
    int aRows;
    int aCol;
    int bRows;
    int bCol;
    int cRows;
    int cCol;
    int col;
    int row;
    pthread_mutex_t* mutex;
    pthread_mutex_t* fileMutex;
    pthread_cond_t* cv;
    FILE* outputFile;
};

int matrixMult(int numOfThreads, struct matrixInfo info);

#endif
